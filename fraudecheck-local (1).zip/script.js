/* FraudeCheck demo — datos ficticios aislados de la interfaz y su comportamiento. */
const DEMO_DATA = {
  model: { precision: 97.6, falsePositiveRate: 1.8, recall: 94.2, latency: 1.2, version: "v2.4.1" },
  validation: { truePositives: 163, falsePositives: 4, falseNegatives: 10, trueNegatives: 223, sampleSize: 400 },
  transactions: [
    { id:"FC-8A42D1", timestamp:"10:42:18", amount:84900, location:"Bogotá, CO", device:"iPhone 14 · Safari", merchant:"Mercado Central", category:"Alimentación", riskScore:8, signals:["Dispositivo habitual","Ubicación frecuente"], label:"Legítima", action:"Aprobada" },
    { id:"FC-8A42CF", timestamp:"10:41:56", amount:1249000, location:"Miami, US", device:"Windows · Chrome", merchant:"TechnoWorld", category:"Electrónica", riskScore:87, signals:["Ubicación inusual","Importe elevado","Dispositivo nuevo"], label:"Sospechosa", action:"Bloqueada" },
    { id:"FC-8A42B9", timestamp:"10:41:32", amount:36500, location:"Medellín, CO", device:"MacBook · Safari", merchant:"Café Brújula", category:"Restauración", riskScore:22, signals:["Dispositivo habitual"], label:"Legítima", action:"Aprobada" },
    { id:"FC-8A429C", timestamp:"10:40:58", amount:679990, location:"Bucarest, RO", device:"Android · Chrome", merchant:"Urban Style", category:"Moda", riskScore:64, signals:["País no habitual","Velocidad de compra alta"], label:"Revisión", action:"Verificación" },
    { id:"FC-8A4286", timestamp:"10:40:17", amount:18200, location:"Cali, CO", device:"iPhone 13 · Safari", merchant:"La Huerta", category:"Alimentación", riskScore:12, signals:["Ubicación frecuente"], label:"Legítima", action:"Aprobada" },
    { id:"FC-8A4271", timestamp:"10:39:44", amount:2190000, location:"Lagos, NG", device:"Linux · Firefox", merchant:"Digital Market", category:"Servicios digitales", riskScore:96, signals:["Ubicación inusual","Importe elevado","Dispositivo nuevo","Patrón de riesgo"], label:"Sospechosa", action:"Bloqueada" },
    { id:"FC-8A425E", timestamp:"10:38:51", amount:142750, location:"Barranquilla, CO", device:"Windows · Edge", merchant:"Casa & Forma", category:"Hogar", riskScore:31, signals:["Importe algo superior"], label:"Legítima", action:"Aprobada" },
    { id:"FC-8A4242", timestamp:"10:37:26", amount:512000, location:"Quito, EC", device:"Android · Chrome", merchant:"Voyage Select", category:"Viajes", riskScore:71, signals:["Ubicación inusual","Dispositivo nuevo"], label:"Revisión", action:"Verificación" },
    { id:"FC-8A4228", timestamp:"10:35:09", amount:55800, location:"Cartagena, CO", device:"iPad · Safari", merchant:"Librería Nube", category:"Cultura", riskScore:6, signals:["Comportamiento normal"], label:"Legítima", action:"Aprobada" },
    { id:"FC-8A420F", timestamp:"10:33:42", amount:899000, location:"Ciudad de México, MX", device:"Windows · Chrome", merchant:"ElectroHub", category:"Electrónica", riskScore:82, signals:["Importe elevado","País no habitual","Múltiples intentos"], label:"Sospechosa", action:"Bloqueada" }
  ],
  activity: [
    { type:"safe", title:"Pago aprobado · FC-8A42D1", detail:"Mercado Central · $84.900 COP", time:"hace 12 s" },
    { type:"block", title:"Riesgo alto bloqueado · FC-8A42CF", detail:"TechnoWorld · $1.249.000 COP · Miami", time:"hace 34 s" },
    { type:"warn", title:"Verificación requerida · FC-8A429C", detail:"Urban Style · $679.990 COP", time:"hace 1 min" },
    { type:"safe", title:"Pago aprobado · FC-8A42B9", detail:"Café Brújula · $36.500 COP", time:"hace 1 min" }
  ]
};

const ICONS = {
  shield:`<svg viewBox="0 0 48 52" fill="none" aria-hidden="true"><path d="M24 2 44 9v13c0 13.2-8.1 22.4-20 28C12.1 44.4 4 35.2 4 22V9L24 2Z" fill="currentColor"/><path d="m15 26 6 6 13-14" stroke="white" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  home:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1V10Z"/><path d="M2 10h20"/></svg>`,
  data:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></svg>`,
  model:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 4a3 3 0 0 0-5 2.2A3.5 3.5 0 0 0 3 12a3.5 3.5 0 0 0 2 5.8A3 3 0 0 0 10 20V4Zm6 0a3 3 0 0 1 5 2.2A3.5 3.5 0 0 1 21 12a3.5 3.5 0 0 1-2 5.8A3 3 0 0 1 14 20V4Z"/><path d="M9 8h2m2 0h2m-8 5h4m2 0h4m-8 4h2m2 0h2"/></svg>`,
  monitor:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 22h8m-4-4v4m-5-9 3-3 3 2 4-5"/><path d="m16 7 3-1v3"/></svg>`,
  results:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 20V10h4v10m4 0V4h4v16m4 0v-7h4v7M2 20h21"/></svg>`,
  search:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 5 5"/></svg>`,
  card:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18m-14 5h4"/></svg>`,
  pulse:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 12h4l3-8 4 16 3-8h4"/></svg>`,
  clock:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>`,
  check:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m5 12 4 4L19 6"/></svg>`,
  alert:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m12 3 10 18H2L12 3Z"/><path d="M12 9v5m0 3h.01"/></svg>`,
  lightning:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m13 2-9 12h7l-1 8 10-13h-7l1-7Z"/></svg>`,
  refresh:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 7v5h-5M4 17v-5h5"/><path d="M6 9a7 7 0 0 1 12-2l2 5M4 12l2 5a7 7 0 0 0 12-2"/></svg>`,
  arrow:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>`,
  close:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m6 6 12 12M18 6 6 18"/></svg>`,
  plus:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 5v14M5 12h14"/></svg>`,
  menu:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 6h16M4 12h16M4 18h16"/></svg>`,
  device:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="6" y="2" width="12" height="20" rx="2"/><path d="M11 18h2"/></svg>`
};
const NAV = [
  ["inicio","Inicio","home"],["datos","Datos","data"],["modelo","Modelo","model"],["monitoreo","Monitoreo","monitor"],["resultados","Resultados","results"]
];
const state = {
  page:"inicio", transactions:DEMO_DATA.transactions.map(x=>({...x,signals:[...x.signals]})),
  activity:DEMO_DATA.activity.map(x=>({...x})), monitoring:true, retraining:false,
  extraAnalyzed:0, blocked:0, approved:0, review:0, search:"", filter:"Todos",
  lastAnalysis:null, liveTicks:0
};
const root = document.getElementById("app");
const money = amount => new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP",maximumFractionDigits:0}).format(amount);
const esc = value => String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const scoreTone = score => score >= 70 ? "high" : score >= 40 ? "mid" : "";
const statusClass = label => label==="Legítima" ? "safe" : label==="Revisión" ? "review" : "blocked";
const statusLabel = label => label==="Legítima" ? "Aprobada" : label==="Revisión" ? "Verificación" : "Bloqueada";
const navIcon = name => ICONS[name] || "";
function pageName(key) { return (NAV.find(n=>n[0]===key)||NAV[0])[1]; }
function toast(message) {
  const node=document.createElement("div"); node.className="toast";
  node.innerHTML=`${ICONS.check}<span>${esc(message)}</span>`;
  document.getElementById("toast-region").appendChild(node);
  window.setTimeout(()=>node.remove(),3200);
}
function pageHead(kicker,title,desc,actions="") {
  return `<div class="page-head"><div><div class="eyebrow"><span class="eyeline"></span>${kicker}</div><h1>${title}</h1><p class="page-description">${desc}</p></div>${actions?`<div class="head-actions">${actions}</div>`:""}</div>`;
}
function iconButton(label,icon,id,extra="") { return `<button class="btn ${extra}" type="button" data-action="${id}" data-testid="button-${id}">${ICONS[icon]}<span>${label}</span></button>`; }
function renderShell(content) {
  root.innerHTML=`<div class="app-shell">
    <aside class="sidebar" id="sidebar" aria-label="Navegación principal">
      <div class="brand"><span class="brand-mark">${ICONS.shield}</span><div><div class="brand-title">FraudeCheck</div><div class="brand-sub">Decisiones claras, pagos seguros</div></div></div>
      <div class="nav-label">Espacio de análisis</div>
      <nav class="nav-list">${NAV.map(([key,label,icon])=>`<button class="nav-link ${state.page===key?"active":""}" type="button" data-page="${key}" aria-current="${state.page===key?"page":"false"}" data-testid="nav-${key}">${navIcon(icon)}<span>${label}</span></button>`).join("")}</nav>
      <div class="sidebar-spacer"></div>
      <div class="side-note"><strong>${ICONS.shield}<span>Entorno de demostración</span></strong><p>Los datos y resultados de esta interfaz son ficticios. No se procesan pagos reales.</p></div>
      <div class="side-footer"><span>FraudeCheck demo</span><span class="version">v0.9.0</span></div>
    </aside>
    <main class="main-area">
      <header class="topbar">
        <div class="topbar-left"><button class="mobile-menu" type="button" id="mobile-menu" aria-label="Abrir navegación" data-testid="button-mobile-menu">${ICONS.menu}</button><span class="topbar-mark">${ICONS.shield}</span><div><div class="topbar-name">FraudeCheck</div><div class="topbar-caption">Análisis de riesgo en pagos en línea</div></div></div>
        <div class="topbar-right"><span class="system-state"><i class="live-dot" style="${state.monitoring?"":"background:#c89b43;box-shadow:0 0 0 4px rgba(200,155,67,.13)"}"></i><span>${state.monitoring?"Sistema activo":"Monitorización pausada"}</span></span><span class="demo-tag">Datos ficticios · Demo</span></div>
      </header>
      <div class="content" id="page-content">${content}</div>
    </main>
  </div>`;
  bindShell();
}
function bindShell() {
  root.querySelectorAll(".nav-link[data-page]").forEach(button=>button.addEventListener("click",()=>go(button.dataset.page)));
  const menu=document.getElementById("mobile-menu");
  menu.addEventListener("click",()=>document.getElementById("sidebar").classList.toggle("open"));
}
function go(page) {
  if(!NAV.some(n=>n[0]===page)) return;
  document.getElementById("sidebar")?.classList.remove("open");
  state.page=page; render(); window.scrollTo({top:0,behavior:"smooth"});
}
function metricCard(label,value,detail,icon,color="") {
  return `<article class="metric-card"><div class="metric-top"><span>${label}</span><span class="metric-icon" style="${color}">${ICONS[icon]}</span></div><div class="metric-value">${value}</div><div class="metric-foot">${detail}</div></article>`;
}
function txRows(transactions) {
  return transactions.map(tx=>`<tr data-open="${esc(tx.id)}" tabindex="0" aria-label="Abrir detalle ${esc(tx.id)}" data-testid="row-transaction-${esc(tx.id)}">
    <td class="tx-id">${esc(tx.id)}</td><td>${esc(tx.timestamp)}</td><td class="tx-merchant">${esc(tx.merchant)}</td><td>${money(tx.amount)}</td><td>${esc(tx.location)}</td>
    <td><div class="risk-meter"><span>${tx.riskScore}</span><span class="risk-track"><span class="risk-fill ${scoreTone(tx.riskScore)}" style="width:${tx.riskScore}%"></span></span></div></td>
    <td><span class="badge ${statusClass(tx.label)}">${esc(statusLabel(tx.label))}</span></td></tr>`).join("");
}
function table(transactions, options={}) {
  const tools=options.tools?`<div class="table-tools"><div class="search-wrap">${ICONS.search}<input class="search-input" id="transaction-search" type="search" placeholder="Buscar ID, comercio o ciudad" aria-label="Buscar transacciones" value="${esc(state.search)}" data-testid="input-transaction-search"></div><select class="select-input" id="transaction-filter" aria-label="Filtrar por decisión" data-testid="select-transaction-filter"><option ${state.filter==="Todos"?"selected":""}>Todos</option><option ${state.filter==="Legítima"?"selected":""}>Legítima</option><option ${state.filter==="Revisión"?"selected":""}>Revisión</option><option ${state.filter==="Sospechosa"?"selected":""}>Sospechosa</option></select></div>`:"";
  return `<section class="panel table-panel"><div class="panel-head"><div><div class="panel-title">${options.title||"Transacciones recientes"}</div><div class="panel-subtitle">${options.subtitle||"Actividad ficticia de la última sesión"}</div></div>${tools||`<button class="text-link" type="button" data-page="datos" data-testid="link-all-transactions">Ver todas ${ICONS.arrow}</button>`}</div>
    <div class="table-scroll"><table class="transactions-table"><thead><tr><th>ID</th><th>Hora</th><th>Comercio</th><th>Importe</th><th>Ubicación</th><th>Riesgo</th><th>Decisión</th></tr></thead><tbody id="${options.tools?"transaction-rows":"recent-rows"}">${transactions.length?txRows(transactions):`<tr><td colspan="7"><div class="empty-state"><div class="empty-icon">${ICONS.search}</div><strong>No hay coincidencias</strong>Prueba con otro término o filtro.</div></td></tr>`}</tbody></table></div>
    <div class="table-footer"><span>${options.footer||`${transactions.length} transacciones de demostración`}</span><span>Selecciona una fila para ver el análisis</span></div></section>`;
}
function activities(items=state.activity.slice(0,4)) {
  return `<div class="activity-list">${items.map((a,i)=>`<div class="activity" data-testid="activity-${i}"><span class="activity-icon ${a.type}">${ICONS[a.type==="safe"?"check":a.type==="block"?"alert":"pulse"]}</span><div class="activity-text"><strong>${esc(a.title)}</strong><span>${esc(a.detail)}</span></div><time>${esc(a.time)}</time></div>`).join("")}</div>`;
}
function homeView() {
  const volume=(12458+state.extraAnalyzed).toLocaleString("es-CO");
  const blocked=17+state.blocked, approved=12082+state.approved;
  return `${pageHead("CENTRO DE CONTROL","Buen día, analista","Una vista clara del riesgo, las decisiones y el estado de la monitorización.",iconButton("Analizar transacción","plus","open-analysis","btn-primary"))}
    <section class="hero-banner"><span class="hero-shield">${ICONS.shield}</span><div class="hero-copy"><h2>Pagos bajo una mirada más clara</h2><p>Detecta señales de riesgo, entiende cada decisión y actúa con confianza.</p></div><div class="hero-aside"><div class="mini-label">Estado del sistema</div><strong>${state.monitoring?"Monitorización activa":"En pausa"}</strong><small>Última actualización: ahora</small></div></section>
    <section class="metric-grid" aria-label="Resumen de métricas">
      ${metricCard("Transacciones analizadas",volume,"<span class='up'>+8,4%</span> frente al periodo anterior","card")}
      ${metricCard("Precisión del modelo",`${DEMO_DATA.model.precision}%`,"Conjunto ilustrativo de validación","model")}
      ${metricCard("Alertas bloqueadas",blocked.toLocaleString("es-CO"),`${state.blocked?"+ "+state.blocked+" en esta sesión":"En datos de demostración"}`,"alert","background:#fbebea;color:#b54b4b")}
      ${metricCard("Latencia media",`${DEMO_DATA.model.latency} s`,"Clasificación local simulada","clock")}
    </section>
    <div class="two-col">
      <section class="panel"><div class="panel-head"><div><div class="panel-title">El recorrido de una decisión</div><div class="panel-subtitle">Tres capas para convertir señales en una respuesta explicable</div></div></div>
        <div class="panel-body"><div class="flow">
          <div class="flow-step"><div class="flow-circle">${ICONS.card}</div><strong>1. Datos</strong><small>${volume} registros ficticios</small></div><div class="flow-arrow">→</div>
          <div class="flow-step"><div class="flow-circle">${ICONS.model}</div><strong>2. Modelo</strong><small>Precisión ${DEMO_DATA.model.precision}%</small></div><div class="flow-arrow">→</div>
          <div class="flow-step"><div class="flow-circle">${ICONS.pulse}</div><strong>3. Monitorización</strong><small>${state.monitoring?"En tiempo real simulado":"Pausada"}</small></div>
        </div></div>
      </section>
      <section class="panel"><div class="panel-head"><div><div class="panel-title">Actividad reciente</div><div class="panel-subtitle">Eventos ficticios del flujo</div></div><button class="text-link" type="button" data-page="monitoreo" data-testid="link-monitor-feed">Abrir monitor</button></div><div class="panel-body">${activities()}</div></section>
    </div>
    <section class="panel workflow-panel"><div class="panel-head"><div><div class="panel-title">Proceso en curso</div><div class="panel-subtitle">Cada pago recorre una secuencia de análisis y decisión</div></div><span class="badge ${state.monitoring?"safe":"review"}">${state.monitoring?"Flujo activo":"Flujo pausado"}</span></div><div class="panel-body"><div class="workflow">
      <div class="workflow-step step-blue">${ICONS.card}<strong>Transacción</strong><small>Datos de entrada</small></div><div class="workflow-arrow">→</div>
      <div class="workflow-step step-violet">${ICONS.model}<strong>Clasificación</strong><small>Análisis de señales</small></div><div class="workflow-arrow">→</div>
      <div class="workflow-step step-green">${ICONS.check}<strong>Legítima</strong><small>Pago aprobado</small></div><div class="workflow-arrow">→</div>
      <div class="workflow-step step-red">${ICONS.alert}<strong>Sospechosa</strong><small>Verificar o bloquear</small></div>
    </div></div></section>
    ${table(state.transactions.slice(0,5))}`;
}
function filterTransactions() {
  const q=state.search.trim().toLocaleLowerCase("es");
  return state.transactions.filter(tx=>{
    const text=[tx.id,tx.merchant,tx.location,tx.category,tx.device].join(" ").toLocaleLowerCase("es");
    return (!q||text.includes(q))&&(state.filter==="Todos"||tx.label===state.filter);
  });
}
function dataView() {
  const all=state.transactions;
  const legit=all.filter(t=>t.label==="Legítima").length, flagged=all.length-legit;
  return `${pageHead("EXPLORADOR DE DATOS","Datos de transacción","Busca, filtra y abre cualquier registro para revisar sus señales y la decisión asignada.",iconButton("Añadir ejemplo","plus","open-analysis","btn-primary"))}
    <div class="metric-grid">
      ${metricCard("Registros visibles",all.length,"Muestra sintética para exploración","data")}
      ${metricCard("Aprobadas",legit,`${all.length?Math.round(legit/all.length*100):0}% del conjunto visible`,"check")}
      ${metricCard("Con señal de riesgo",flagged,"Revisión o bloqueo preventivo","alert","background:#fbf1dc;color:#a56b14")}
      ${metricCard("Cobertura", "5","Campos de contexto por operación","pulse")}
    </div>
    <div class="filter-row"><div class="filter-label">Explora el conjunto</div><div class="count-note">Las filas y etiquetas son datos ficticios de demostración</div></div>
    ${table(filterTransactions(),{title:"Registro de operaciones",subtitle:"Ordenado por hora de análisis · pulsa una fila para abrir el detalle",tools:true,footer:`Mostrando ${filterTransactions().length} de ${all.length} registros`})}
    <div class="notice" style="margin-top:13px">Las ubicaciones, importes, comercios e identificadores son ejemplos inventados. No corresponden a pagos reales ni a personas reales.</div>`;
}
function modelView() {
  const values=[95.4,96.1,95.8,96.9,96.5,97.1,96.8,97.6];
  return `${pageHead("CALIDAD DEL MODELO","Modelo de riesgo","Indicadores ilustrativos de validación y un ciclo de mejora que puedes simular localmente.",`<button class="btn btn-primary" type="button" data-action="retrain" data-testid="button-retrain" ${state.retraining?"disabled":""}>${ICONS.refresh}<span>${state.retraining?"Reentrenando…":"Ejecutar reentrenamiento"}</span></button>`)}
    <section class="model-hero"><div class="model-kicker">Modelo demostrativo · ${DEMO_DATA.model.version}</div><h2>Clasificación explicable, latencia ligera</h2><p>Esta vista presenta métricas de ejemplo. La decisión de la demo se calcula en el navegador mediante reglas transparentes; no hay modelo remoto ni aprendizaje real.</p><div class="model-stats">
      <div class="model-stat"><strong>${DEMO_DATA.model.precision}%</strong><span>Precisión</span></div><div class="model-stat"><strong>${DEMO_DATA.model.recall}%</strong><span>Detección de fraude</span></div><div class="model-stat"><strong>${DEMO_DATA.model.latency} s</strong><span>Latencia ilustrativa</span></div>
    </div></section>
    <div class="two-col" style="margin-top:15px">
      <section class="panel chart-panel"><div class="panel-head"><div><div class="panel-title">Precisión por iteración</div><div class="panel-subtitle">Evolución ilustrativa en validación</div></div><span class="badge safe">Estable</span></div>
        <div class="chart" role="img" aria-label="Gráfico de precisión ilustrativa, de 95,4 a 97,6 por ciento"><div class="chart-grid"><span></span><span></span><span></span><span></span></div><div class="chart-bars">${values.map((v,i)=>`<div class="chart-bar-wrap"><div class="chart-bar" style="height:${Math.max(20,(v-90)*13)}%"></div><span>${v.toFixed(1).replace(".",",")}</span></div>`).join("")}</div></div><div class="chart-labels"><span>Iteración 01</span><span>Iteración 04</span><span>Iteración 08</span></div>
      </section>
      <section class="panel"><div class="panel-head"><div><div class="panel-title">Balance de errores</div><div class="panel-subtitle">Conjunto de validación ficticio</div></div></div><div class="panel-body">
        <div class="signal-row"><span>Falsos positivos</span><strong>${DEMO_DATA.model.falsePositiveRate}%</strong></div><div class="signal-row"><span>Fraude detectado</span><strong>${DEMO_DATA.model.recall}%</strong></div><div class="signal-row"><span>Precisión global</span><strong>${DEMO_DATA.model.precision}%</strong></div><div class="signal-row"><span>Latencia media</span><strong>${DEMO_DATA.model.latency} s</strong></div>
        <div class="notice" style="margin-top:13px">Las métricas son orientativas; no describen el rendimiento de un sistema financiero real.</div>
      </div></section>
    </div>
    <section class="panel" style="margin-top:15px"><div class="panel-head"><div><div class="panel-title">Bucle de mejora</div><div class="panel-subtitle">De los datos de ejemplo a una evaluación simulada</div></div></div><div class="panel-body" style="padding:16px"><div class="loop-grid">
      <div class="loop-step"><span class="n">1</span><strong>Reunir señales</strong><p>Historial sintético de pagos, contextos y etiquetas.</p></div>
      <div class="loop-step"><span class="n">2</span><strong>Reentrenar</strong><p>Simula una breve actualización del ciclo de modelo.</p></div>
      <div class="loop-step"><span class="n">3</span><strong>Validar equilibrio</strong><p>Revisar precisión y reducir falsas alarmas.</p></div>
      <div class="loop-step"><span class="n">4</span><strong>Monitorizar</strong><p>Observar decisiones, latencia y señales nuevas.</p></div>
    </div></div></section>`;
}
function monitorView() {
  const latest=state.activity.slice(0,7);
  return `${pageHead("OPERACIÓN EN DIRECTO","Monitorización","Observa un flujo simulado y analiza un nuevo ejemplo con reglas visibles y una decisión explicable.",`<button class="btn ${state.monitoring?"btn-quiet":"btn-green"}" type="button" data-action="toggle-monitor" aria-pressed="${state.monitoring}" data-testid="button-toggle-monitor">${state.monitoring?ICONS.pulse:ICONS.check}<span>${state.monitoring?"Pausar monitor":"Reanudar monitor"}</span></button>`)}
    <div class="monitor-banner ${state.monitoring?"":"paused"}"><div class="monitor-left"><span class="monitor-icon">${state.monitoring?ICONS.pulse:ICONS.clock}</span><div><strong>${state.monitoring?"Flujo de análisis activo":"Monitorización pausada"}</strong><span>${state.monitoring?"La actividad que ves se genera localmente y es solo demostrativa.":"Los eventos no avanzarán hasta que reanudes la simulación."}</span></div></div><span class="badge ${state.monitoring?"safe":"review"}">${state.monitoring?"SIMULACIÓN ACTIVA":"EN PAUSA"}</span></div>
    <div class="feed-layout">
      <section class="panel"><div class="panel-head"><div><div class="panel-title">Feed de actividad</div><div class="panel-subtitle">Eventos recientes generados para esta demostración</div></div><span class="badge neutral">${latest.length} eventos</span></div><div class="feed-list">${latest.map((a,i)=>`<div class="feed-event" data-testid="feed-event-${i}"><span class="feed-symbol">${ICONS[a.type==="safe"?"check":a.type==="block"?"alert":"pulse"]}</span><div class="feed-copy"><strong>${esc(a.title)}</strong><span>${esc(a.detail)}</span></div><div class="feed-right"><strong class="badge ${a.type==="safe"?"safe":a.type==="block"?"blocked":"review"}">${a.type==="safe"?"Aprobada":a.type==="block"?"Bloqueada":"Verificar"}</strong><small>${esc(a.time)}</small></div></div>`).join("")}</div><div class="table-footer"><span>${state.monitoring?"Actualización simulada activa":"Feed congelado"}</span><span>Sin conexión con servicios externos</span></div></section>
      <section class="panel"><div class="panel-head"><div><div class="panel-title">Probar una operación</div><div class="panel-subtitle">Introduce valores y calcula un score basado en reglas</div></div></div><div class="panel-body">
        <form id="analysis-form" data-testid="form-analysis">
          <div class="form-grid">
            <div class="field"><label for="amount">Importe (COP)</label><input class="field-input" id="amount" name="amount" type="number" min="1" max="50000000" step="1000" value="185000" required data-testid="input-amount"></div>
            <div class="field"><label for="location">Ubicación</label><select class="field-input" id="location" name="location" data-testid="select-location"><option value="Bogotá, CO">Bogotá, Colombia</option><option value="Medellín, CO">Medellín, Colombia</option><option value="Cali, CO">Cali, Colombia</option><option value="Barranquilla, CO">Barranquilla, Colombia</option><option value="Miami, US">Miami, Estados Unidos</option><option value="Quito, EC">Quito, Ecuador</option></select></div>
            <div class="field"><label for="category">Categoría</label><select class="field-input" id="category" name="category" data-testid="select-category"><option>Electrónica</option><option>Alimentación</option><option>Viajes</option><option>Moda</option><option>Servicios digitales</option><option>Hogar</option><option>Restauración</option></select></div>
            <div class="field"><label for="device">Dispositivo</label><select class="field-input" id="device" name="device" data-testid="select-device"><option value="Habitual">Habitual</option><option value="Nuevo">Nuevo</option></select></div>
            <div class="field full"><label for="merchant">Comercio de ejemplo</label><input class="field-input" id="merchant" name="merchant" maxlength="50" value="Comercio de prueba" required data-testid="input-merchant"></div>
          </div>
          <p class="form-hint">Reglas visibles: importe &gt; $500.000 COP (+25), ubicación fuera de Colombia (+30), dispositivo nuevo (+25), categoría digital (+12). Score de 0 a 100.</p>
          <button class="btn btn-primary" type="submit" style="width:100%" data-testid="button-analyze">${ICONS.pulse}<span>Calcular riesgo</span></button>
        </form>
        <div class="analysis-result" id="analysis-result" aria-live="polite"></div>
      </div></section>
    </div>`;
}
function resultsView() {
  const {truePositives:caught,falsePositives:falsePositive,falseNegatives:missed,trueNegatives,sampleSize}=DEMO_DATA.validation;
  const latency=DEMO_DATA.model.latency;
  return `${pageHead("EVALUACIÓN","Resultados del análisis","Una lectura sencilla de los indicadores clave y del equilibrio entre detección y fricción.",iconButton("Ir a monitorización","monitor","go-monitor",""))}
    <div class="result-summary-grid">
      <article class="result-card green"><div class="label">Precisión</div><div class="number">${DEMO_DATA.model.precision}%</div><div class="detail">Decisiones correctas entre alertas</div></article>
      <article class="result-card"><div class="label">Fraude detectado</div><div class="number">${caught.toLocaleString("es-CO")}</div><div class="detail">${DEMO_DATA.model.recall}% de detección · validación ficticia</div></article>
      <article class="result-card red"><div class="label">Fraude no detectado</div><div class="number">${missed}</div><div class="detail">Estimación en conjunto ficticio</div></article>
      <article class="result-card amber"><div class="label">Falsos positivos</div><div class="number">${falsePositive}</div><div class="detail">${DEMO_DATA.model.falsePositiveRate}% de la muestra</div></article>
    </div>
    <div class="two-col">
      <section class="panel"><div class="panel-head"><div><div class="panel-title">Matriz de decisiones</div><div class="panel-subtitle">Muestra etiquetada ficticia · observación frente a clasificación</div></div><span class="badge neutral">N = ${sampleSize}</span></div><div class="panel-body">
        <div class="notice">En un sistema real, estos valores se obtienen con etiquetas confirmadas y un periodo de evaluación definido.</div>
        <div class="confusion"><div class="confusion-cell tp"><span>Fraude detectado</span><strong>${caught}</strong></div><div class="confusion-cell fp"><span>Falsa alarma</span><strong>${falsePositive}</strong></div><div class="confusion-cell fn"><span>Fraude omitido</span><strong>${missed}</strong></div><div class="confusion-cell tn"><span>Pago legítimo</span><strong>${trueNegatives}</strong></div></div>
      </div></section>
      <section class="panel"><div class="panel-head"><div><div class="panel-title">Velocidad y balance</div><div class="panel-subtitle">Latencia media de decisión</div></div></div><div class="panel-body">
        <div style="display:flex;align-items:center;gap:14px;padding:12px 0 18px"><span class="metric-icon">${ICONS.clock}</span><div><div style="font-size:27px;font-weight:750;letter-spacing:-.8px;color:#1b3552">${latency} s</div><div style="font-size:10px;color:#8291a1;margin-top:3px">Valor demostrativo</div></div></div>
        <div class="signal-row"><span>Detección (recall)</span><strong>${DEMO_DATA.model.recall}%</strong></div><div class="signal-row"><span>Falsos positivos</span><strong>${DEMO_DATA.model.falsePositiveRate}%</strong></div><div class="signal-row"><span>Precisión</span><strong>${DEMO_DATA.model.precision}%</strong></div>
      </div></section>
    </div>
    <section class="panel" style="margin-top:15px"><div class="panel-head"><div><div class="panel-title">Qué significa cada indicador</div><div class="panel-subtitle">Una guía rápida para revisar los resultados con criterio</div></div></div><div class="panel-body"><div class="two-col" style="gap:25px">
      <div><strong style="font-size:11px">Detección alta, sin perder contexto</strong><p class="form-hint">Una tasa de detección mayor reduce pagos fraudulentos no vistos, pero conviene vigilar también el coste de las alertas equivocadas.</p></div>
      <div><strong style="font-size:11px">Precisión y experiencia de pago</strong><p class="form-hint">La precisión estima cuántas alertas son realmente relevantes. Los falsos positivos pueden añadir fricción a pagos legítimos.</p></div>
    </div></div></section>`;
}
function render() {
  let content=state.page==="inicio"?homeView():state.page==="datos"?dataView():state.page==="modelo"?modelView():state.page==="monitoreo"?monitorView():resultsView();
  renderShell(content); bindPage();
}
function openDetail(id) {
  const tx=state.transactions.find(t=>t.id===id); if(!tx)return;
  document.getElementById("modal-title").textContent=`Transacción ${tx.id}`;
  document.getElementById("modal-subtitle").textContent=`Analizada a las ${tx.timestamp} · ${tx.category}`;
  document.getElementById("modal-body").innerHTML=`<div class="detail-top"><div><span class="badge ${statusClass(tx.label)}">${esc(statusLabel(tx.label))}</span><div style="font-size:10px;color:#8493a1;margin-top:7px">Decisión de demostración</div></div><div style="text-align:right"><div class="detail-score">${tx.riskScore}<span style="font-size:11px;color:#8794a2"> / 100</span></div><div class="risk-track" style="width:92px;margin:5px 0 0 auto"><span class="risk-fill ${scoreTone(tx.riskScore)}" style="width:${tx.riskScore}%"></span></div></div></div>
    <div class="detail-grid">
      <div class="detail-item"><label>Importe</label><strong>${money(tx.amount)}</strong></div><div class="detail-item"><label>Comercio</label><strong>${esc(tx.merchant)}</strong></div>
      <div class="detail-item"><label>Ubicación</label><strong>${esc(tx.location)}</strong></div><div class="detail-item"><label>Dispositivo</label><strong>${esc(tx.device)}</strong></div>
      <div class="detail-item"><label>Categoría</label><strong>${esc(tx.category)}</strong></div><div class="detail-item"><label>Acción</label><strong>${esc(tx.action)}</strong></div>
    </div><div class="detail-signals"><h3>Señales consideradas</h3>${tx.signals.map(s=>`<span class="signal-chip">${esc(s)}</span>`).join("")}</div>
    <p class="form-hint" style="margin:13px 0 0">Puntuación ilustrativa. La decisión no afecta a ningún pago real.</p>`;
  const modal=document.getElementById("modal"); modal.classList.add("open"); document.getElementById("close-modal").focus();
}
function calculateRisk(formData) {
  const amount=Number(formData.get("amount")), location=formData.get("location"), device=formData.get("device"), category=formData.get("category");
  let score=8, signals=["Comportamiento de referencia"];
  if(amount>500000){score+=25;signals.push("Importe elevado: +25");}
  if(!location.endsWith(", CO")){score+=30;signals.push("Ubicación fuera de Colombia: +30");}
  if(device==="Nuevo"){score+=25;signals.push("Dispositivo nuevo: +25");}
  if(category==="Servicios digitales"){score+=12;signals.push("Categoría digital: +12");}
  if(amount>1500000){score+=10;signals.push("Importe muy elevado: +10");}
  score=Math.min(score,100);
  const label=score>=70?"Sospechosa":score>=40?"Revisión":"Legítima";
  return {score,label,signals};
}
function runAnalysis(form) {
  const fd=new FormData(form), amount=Number(fd.get("amount"));
  if(!Number.isFinite(amount)||amount<=0){form.querySelector('[name="amount"]').focus();toast("Introduce un importe válido.");return;}
  const {score,label,signals}=calculateRisk(fd);
  const id=`FC-DEMO-${String(state.extraAnalyzed+1).padStart(3,"0")}`;
  const tx={id,timestamp:new Date().toLocaleTimeString("es-CO",{hour:"2-digit",minute:"2-digit",second:"2-digit"}),amount,location:fd.get("location"),device:fd.get("device")==="Nuevo"?"Dispositivo nuevo":"Dispositivo habitual",merchant:fd.get("merchant").trim()||"Comercio de prueba",category:fd.get("category"),riskScore:score,signals,label,action:statusLabel(label)};
  state.transactions.unshift(tx); state.extraAnalyzed++;
  if(label==="Sospechosa")state.blocked++; else if(label==="Revisión")state.review++; else state.approved++;
  state.activity.unshift({type:label==="Legítima"?"safe":label==="Revisión"?"warn":"block",title:`${label==="Legítima"?"Pago aprobado":label==="Revisión"?"Verificación requerida":"Riesgo alto bloqueado"} · ${id}`,detail:`${tx.merchant} · ${money(amount)} · ${tx.location}`,time:"ahora"});
  state.lastAnalysis=tx;
  const result=document.getElementById("analysis-result");
  result.innerHTML=`<div class="result-heading"><strong>Resultado del análisis</strong><span class="badge ${statusClass(label)}">${statusLabel(label)}</span></div><div class="score-line"><span class="score-number">${score}</span><span class="form-hint">score / 100</span><span class="score-track"><span class="${scoreTone(score)}" style="width:${score}%"></span></span></div><ul class="result-reasons">${signals.map(s=>`<li>${esc(s)}</li>`).join("")}</ul><p class="form-hint" style="margin:11px 0 0">Regla transparente · ${esc(id)} · Sin impacto en pagos reales.</p>`;
  result.classList.add("show"); toast(`Análisis completado: ${statusLabel(label).toLocaleLowerCase("es")}.`);
}
function bindPage() {
  root.querySelectorAll("[data-page]").forEach(btn=>btn.addEventListener("click",()=>go(btn.dataset.page)));
  root.querySelectorAll("[data-action]").forEach(btn=>btn.addEventListener("click",()=>{
    const action=btn.dataset.action;
    if(action==="open-analysis"){go("monitoreo");window.setTimeout(()=>document.getElementById("amount")?.focus(),80);}
    if(action==="go-monitor")go("monitoreo");
    if(action==="toggle-monitor"){state.monitoring=!state.monitoring;render();toast(state.monitoring?"Monitorización reanudada.":"Monitorización pausada.");}
    if(action==="retrain")retrain(btn);
  }));
  root.querySelectorAll("[data-open]").forEach(row=>{
    row.addEventListener("click",()=>openDetail(row.dataset.open));
    row.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();openDetail(row.dataset.open);}});
  });
  const search=document.getElementById("transaction-search");
  if(search)search.addEventListener("input",()=>{state.search=search.value;refreshDataTable();});
  const filter=document.getElementById("transaction-filter");
  if(filter)filter.addEventListener("change",()=>{state.filter=filter.value;refreshDataTable();});
  const form=document.getElementById("analysis-form");
  if(form)form.addEventListener("submit",e=>{e.preventDefault();runAnalysis(form);});
}
function refreshDataTable() {
  const rows=document.getElementById("transaction-rows"); if(!rows)return;
  const filtered=filterTransactions();
  rows.innerHTML=filtered.length?txRows(filtered):`<tr><td colspan="7"><div class="empty-state"><div class="empty-icon">${ICONS.search}</div><strong>No hay coincidencias</strong>Prueba con otro término o filtro.</div></td></tr>`;
  document.querySelector(".table-footer span").textContent=`Mostrando ${filtered.length} de ${state.transactions.length} registros`;
  rows.querySelectorAll("[data-open]").forEach(row=>{
    row.addEventListener("click",()=>openDetail(row.dataset.open));
    row.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();openDetail(row.dataset.open);}});
  });
}
function retrain(button) {
  if(state.retraining)return;
  state.retraining=true; button.disabled=true; button.innerHTML=`${ICONS.refresh}<span>Reuniendo señales…</span>`;
  toast("Ciclo local de reentrenamiento iniciado.");
  window.setTimeout(()=>{button.innerHTML=`${ICONS.refresh}<span>Validando métricas…</span>`;},650);
  window.setTimeout(()=>{state.retraining=false;render();toast("Simulación completada. Las métricas siguen siendo ilustrativas.");},1500);
}
document.getElementById("close-modal").addEventListener("click",()=>document.getElementById("modal").classList.remove("open"));
document.getElementById("modal").addEventListener("click",e=>{if(e.target.id==="modal")e.currentTarget.classList.remove("open");});
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.getElementById("modal").classList.remove("open");});
render();